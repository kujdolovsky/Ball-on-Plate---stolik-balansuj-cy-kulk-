#include "GetPoint.h"
#include "Arduino.h"
#include "Touchscreen.h"

#define YP A0
#define XM A1
#define YM A2
#define XP A3


TouchScreen ts = TouchScreen(XP, YP, XM, YM, 0);


void setupFunctionGetPoint(){
}

// Xpos uint16 [1,1]
// Ypos uint16 [1,1]


void stepFunctionGetPoint(uint16_T * Xpos,int size_vector_1,uint16_T * Ypos,int size_vector_2){
  TSPoint p = ts.getPoint();

  pinMode(XM, OUTPUT);
  pinMode(YP, OUTPUT);

    if(p.x!=0 && p.y!=0){
  *Xpos= p.x;
  *Ypos = p.y;
    }
    else{
        *Xpos=512;
  *Ypos = 512; 
    }
}